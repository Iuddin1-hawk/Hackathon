namespace INTCAPI;

// Object used to hold an incoming queued call.
public class IncomingQueuedCall
{

    public string CallID { get; set; } // The CallID is the unique identifier for the call.
    public string RecentCorrelationID { get; set; } // RecentCorrelationID is the correlationID of the most recent action taken on the call.

    public CallState CallsState { get; set; }
    public Call? CallEvent { get; set; } // The Call object itself. Taken from the incoming callEvent on an "inbound" and "presented" call.
    public IncomingQueuedCall()
    {
        CallID = "";
        RecentCorrelationID = "";
        CallsState = CallState.Presented; // All new inbound calls are presented.
    }

    public enum CallState
    {
        Presented, // The state where a call has been presented to the queue as new, but has not yet been accepted or rejected.
        Answering, // The state where an accept method has been called, but the call has not yet recieved a response.
        Answered, // The state where an accept method has been called and the call has been accepted with a response.
        Ended, // The state where a call has been requested to end, and recieved a response.
        Ending, // The state where a call has been requested to end with the endCall method and has not yet recieved a response.
    }
}