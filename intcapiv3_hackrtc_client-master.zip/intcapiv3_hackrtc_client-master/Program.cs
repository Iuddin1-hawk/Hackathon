﻿using static INTCAPI.ConnectionRSM;
using System.Text;
using Spectre.Console;
using Newtonsoft.Json;
using System.Net.WebSockets;

namespace INTCAPI;

public class Program
{
    public class Configuration
    {
        public string? Uri { get; set; } //URI for the demo server. "ws://hackrtc.indigital.dev:8800/text-control-api/v3"
        public string? Username { get; set; }
        public string? Password { get; set; }
        public string? AgencyId { get; set; }
        public string? Secret { get; set; }
    }


    private static readonly List<string> commands = new()
    {
        "exit",
        "showConfig",
        "editConfig",
        "connect",
        "disconnect",
        "acceptCall",
        "endCall",
        "setActiveCall",
        "clearActiveCall",
        "listCalls",
        "showMessages",
        "purgeCalls",
        "history",
        "debug",
        "help"
    };
    private static ConnectionRSM? connectionRSM;
    private static CancellationTokenSource processCallQueueTaskTokenSource = new();
    public static string activeCallId = "";
    private static List<string> incomingCallList = new();
    private static Dictionary<string, List<Events.Message>> messages = new();
    private static Configuration config = new();

    // load configuration from file
    public static async Task<Configuration> LoadConfiguration()
    {
        const string configPath = "config.json";

        if (!File.Exists(configPath))
        {
            // Create a default configuration with empty values
            var defaultConfig = new Configuration();

            // Write this default configuration to the file
            var jsonString = JsonConvert.SerializeObject(defaultConfig, Formatting.Indented); // Indented for prettier formatting
            await File.WriteAllTextAsync(configPath, jsonString);

            return defaultConfig;
        }

        // Read the configuration from the file
        try
        {
            var config = JsonConvert.DeserializeObject<Configuration>(await File.ReadAllTextAsync(configPath));
            if (config != null)
                return config;
            else
            {
                // Create a default configuration with empty values
                var defaultConfig = new Configuration();
                return defaultConfig;
            }
        }
        catch (Exception e)
        {
            AnsiConsole.MarkupLine("[bold red]Error parsing config.json[/]");
            AnsiConsole.MarkupLine("[bold red]Please check your config.json file for errors.[/]");
            AnsiConsole.MarkupLine("[bold red]Error: " + e.Message + "[/]");
            return new Configuration();
        }
    }

    // save configuration to file
    public static void SaveConfiguration(Configuration config)
    {
        const string configPath = "config.json";

        // Write this default configuration to the file
        var jsonString = JsonConvert.SerializeObject(config, Formatting.Indented); // Indented for prettier formatting
        File.WriteAllText(configPath, jsonString);
    }

    private static void DisplayPrompt(string tabCompletion = "")
    {
        string csEmoji = ":red_circle:";

        if (connectionRSM != null)
        {
            if (connectionRSM.webSocketClient?._webSocket?.State == WebSocketState.Open)
            {
                csEmoji = ":green_circle:";
            }
        }

        string prompt = activeCallId.Length > 0 ? csEmoji + " Program -> " + activeCallId + ": " : csEmoji + " Program: ";
        AnsiConsole.Markup("[bold fuchsia]" + prompt + "[/]" + tabCompletion);
    }

    private static readonly List<string> commandHistory = new();
    private static int historyIndex = -1;
    private static readonly string historyFilePath = "commandHistory.txt";

    private static void LoadCommandHistory()
    {
        if (File.Exists(historyFilePath))
        {
            commandHistory.AddRange(File.ReadAllLines(historyFilePath));
            historyIndex = commandHistory.Count;
        }
    }

    private static void SaveCommandHistory()
    {
        // Only save the last 100 commands
        if (commandHistory.Count > 100)
        {
            commandHistory.RemoveRange(0, commandHistory.Count - 100);
        }

        // do not append to file, overwrite it
        File.WriteAllLines(historyFilePath, commandHistory);
    }


    private static string ReadLineWithTabCompletion()
    {
        StringBuilder input = new();
        ConsoleKeyInfo keyInfo;

        DisplayPrompt();
        while (true)
        {
            keyInfo = Console.ReadKey(intercept: true);

            if (keyInfo.Key == ConsoleKey.Enter)
            {
                AnsiConsole.WriteLine();
                if (input.Length > 0)
                {
                    commandHistory.Add(input.ToString()); // Save command to history
                    SaveCommandHistory(); // Save history to file
                    historyIndex = commandHistory.Count;  // Reset history index
                }
                return input.ToString();
            }
            else if (keyInfo.Key == ConsoleKey.Tab)
            {
                // break down the input into parts
                string[] parts = input.ToString().Split(' ');

                // Find the closest matching command
                var match = commands.FirstOrDefault(c => c.StartsWith(parts[0].ToString().Trim()));

                if (match != null)
                {

                    // Clear the current input line
                    ClearCurrentLine();
                    DisplayPrompt();
                    input.Clear();
                    input.Append(match);
                    AnsiConsole.Write(match);
                }
            }
            else if (keyInfo.Key == ConsoleKey.Backspace)
            {
                if (input.Length > 0)
                {
                    // Remove last character
                    input.Remove(input.Length - 1, 1);
                    // Clear the current input line
                    ClearCurrentLine();
                    DisplayPrompt(input.ToString());
                }
            }
            else if (keyInfo.Key == ConsoleKey.UpArrow)
            {
                // Move to previous command
                if (historyIndex > 0)
                {
                    historyIndex--;
                    ClearCurrentLine();
                    input.Clear();
                    input.Append(commandHistory[historyIndex]);
                    DisplayPrompt(input.ToString());
                }
            }
            else if (keyInfo.Key == ConsoleKey.DownArrow)
            {
                // Move to next command
                if (historyIndex < commandHistory.Count - 1)
                {
                    historyIndex++;
                    ClearCurrentLine();
                    input.Clear();
                    input.Append(commandHistory[historyIndex]);
                    DisplayPrompt(input.ToString());
                }
                else if (historyIndex == commandHistory.Count - 1) // If at the end, clear to a new command
                {
                    historyIndex++;
                    ClearCurrentLine();
                    input.Clear();
                    DisplayPrompt();
                }
            }
            else
            {
                if (keyInfo.Modifiers == ConsoleModifiers.Control && keyInfo.Key == ConsoleKey.C)
                {
                    ClearCurrentLine();
                    AnsiConsole.MarkupLine("[bold red]Ctrl+C is not supported. Please use the [/][bold yellow]exit[/][bold red] command.[/]");
                    DisplayPrompt();
                    continue;
                }
                else
                {
                    Console.Write(keyInfo.KeyChar);
                    input.Append(keyInfo.KeyChar);
                }
            }
        }
    }

    private static void ClearCurrentLine()
    {
        // clear the current line
        Console.Write("\r" + new string(' ', Console.WindowWidth - 1) + "\r");
    }

    public static void WelcomeScreen()
    {
        Console.Clear();
        AnsiConsole.WriteLine();
        AnsiConsole.WriteLine();
        AnsiConsole.Write(new Rule("[red]INdigital[/]"));
        AnsiConsole.Write(new FigletText("HackRTC 2023").Centered().Color(Color.Red));
        AnsiConsole.Write(new Rule());
        AnsiConsole.WriteLine();
        AnsiConsole.WriteLine();
        AnsiConsole.MarkupLine("[lime]Welcome to the challenge! This is a sample application that connects to INdigital Text Control API using WebSockets. This is essentially a call taking position that allows a user to answer calls and send messages.[/]");
        AnsiConsole.WriteLine();
        AnsiConsole.MarkupLine("[darkgoldenrod]For more information about this challenge, visit:[/] [link=https://hackrtc.indigital.dev]https://hackrtc.indigital.dev[/]");
        AnsiConsole.WriteLine();
        AnsiConsole.MarkupLine("[red]To see what commands are available, type: [bold yellow]help[/][/]");
        AnsiConsole.WriteLine();
        AnsiConsole.MarkupLine("Happy Hacking! :nerd_face:");
        AnsiConsole.WriteLine();
    }

    public static async Task Main(string[] args)
    {
        //URL for the demo server. "ws://hackrtc.indigital.dev:8800/text-control-api/v3"

        string help = "\n[bold]Commands:[/]\n\n  [bold yellow]exit[/] - Exit the program\n  [bold yellow]showConfig[/] - Shows the current configuration\n  [bold yellow]editConfig[/] - Create or Update existing configuration\n  [bold yellow]connect[/] - Connect to TCAPI\n  [bold yellow]disconnect[/] - Disconnect from TCAPI\n  [bold yellow]acceptCall[/] - Accepts the first call in the queue\n  [bold yellow]endCall[/] [bold dodgerblue1][[callId]][/] - Ends the current active call or a call with the callId value\n  [bold yellow]listCalls[/] - Lists out all calls in the queue\n  [bold yellow]showMessages[/] [bold dodgerblue1][[callId]][/] - Shows messages for current active call or for a call ID\n  [bold yellow]purgeCalls[/] - Purges ended and missed calls from the queue\n  [bold yellow]setActiveCall[/] [bold dodgerblue1][[callId]][/] - Refocuses the program to a call\n  [bold yellow]clearActiveCall[/] - Resets the programs focus\n  [bold yellow]history[/] - Show command history\n  [bold yellow]debug[/] [bold dodgerblue1][[on|off]][/] - Turn on/off debugging\n  [bold yellow]help[/] - This help message\n\n";

        WelcomeScreen();
        LoadCommandHistory(); // Load history from file

        Console.TreatControlCAsInput = true;

        //Command line interface to answer calls.
        while (true)
        {

            string? userInput = ReadLineWithTabCompletion();

            if (userInput == "") continue;
            if (userInput == null) continue;

            string[] parts = userInput.Split(' ');
            async Task sendMessage()
            {
                if (connectionRSM == null)
                {
                    AnsiConsole.MarkupLine("[bold red]Connection is null. Cannot send message.[/]");
                    return;
                }

                string message = "";
                for (int i = 0; i < parts.Length; i++)
                {
                    message += parts[i];
                    if (i < parts.Length - 1) message += " ";
                }
                ConsoleInput consoleInput = new()
                {
                    callId = activeCallId,
                    message = message
                };
                await HandleEvent(ConnectionRSM.Action.SendMessage, connectionRSM, null, consoleInput);
                AnsiConsole.MarkupLine("[bold dodgerblue1]Message Received [/][lime]:up_right_arrow:[/][bold dodgerblue1] - [/][bold yellow]" + message + "[/]");

                // add message to messages dictionary
                if (messages.ContainsKey(activeCallId))
                {
                    messages[activeCallId].Add(new Events.Message()
                    {
                        from = "me",
                        body = message,
                        dateTime = DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss.fff tt").ToString()
                    });
                }
                else
                {
                    messages.Add(activeCallId, new List<Events.Message>() { new Events.Message()
                    {
                        from = "me",
                        body = message,
                        dateTime = DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss.fff tt").ToString()
                    } });
                }
            }
            async Task disconnect()
            {
                if (connectionRSM == null)
                {
                    AnsiConsole.MarkupLine("[bold red]Cannot run this command until connected.[/]");
                    return;
                }

                await AnsiConsole.Status()
                    .StartAsync("Disconnecting from " + config.Uri, async ctx =>
                    {
                        ctx.Spinner(Spinner.Known.Pong);
                        ctx.SpinnerStyle(Style.Parse("yellow"));

                        await HandleEvent(ConnectionRSM.Action.UnsubscribeAgency, connectionRSM, RSMTestable.Testable.AgencySubscription, RSMStates.AgencyUnsubscribed, 1000);
                        await HandleEvent(ConnectionRSM.Action.Disconnect, connectionRSM, RSMTestable.Testable.Connection, RSMStates.ConnectionDisconnected, 1000);

                        if (connectionRSM.stateRSM.connectionState == RSMStates.ConnectionDisconnected)
                        {
                            AnsiConsole.MarkupLine("[bold lime]Disconnected[/]");
                            try
                            {
                                processCallQueueTaskTokenSource.Cancel();
                            }
                            catch (Exception e)
                            {
                                AnsiConsole.WriteException(e);
                            }
                            finally
                            {
                                // dispose the connectionRSM
                                connectionRSM.Dispose();
                            }
                        }
                        else
                        {
                            AnsiConsole.MarkupLine("[bold red]Disconnect Failed[/]");
                        }
                    });
            }
            if (parts.Length == 1)
            {
                if (parts[0] == "exit")
                {
                    AnsiConsole.MarkupLine("[bold dodgerblue1]Cleaning up calls & connection...[/]");

                    if (connectionRSM == null)
                    {
                        // just exit
                        break;
                    }

                    // create await tasks array
                    List<Task> exitTasks = new();

                    // any queued calls that have been answered?
                    foreach (var queuedCall in connectionRSM.callQueue)
                    {
                        if (queuedCall.Value.CallsState == IncomingQueuedCall.CallState.Answered)
                        {
                            // end this call
                            ConsoleInput consoleInput = new()
                            {
                                callId = activeCallId
                            };
                            // await HandleEvent(ConnectionRSM.Action.EndCall, connectionRSM, null, consoleInput);
                            exitTasks.Add(HandleEvent(ConnectionRSM.Action.EndCall, connectionRSM, null, consoleInput));
                        }
                    }

                    exitTasks.Add(HandleEvent(ConnectionRSM.Action.UnsubscribeAgency, connectionRSM, RSMTestable.Testable.AgencySubscription, RSMStates.AgencyUnsubscribed, 1000));
                    exitTasks.Add(HandleEvent(ConnectionRSM.Action.Disconnect, connectionRSM, RSMTestable.Testable.Connection, RSMStates.ConnectionDisconnected, 1000));

                    await Task.WhenAll(exitTasks);
                    AnsiConsole.MarkupLine("[bold dodgerblue1]Cleaned up. Exiting program.[/]");
                    break;
                }
                else if (parts[0] == "debug")
                {
                    // show debugging status
                    AnsiConsole.MarkupLine("[bold dodgerblue1]Debugging is " + (DebuggingEnabled ? "enabled" : "disabled") + "[/]");

                    // show usage of how to turn on/off debugging
                    AnsiConsole.MarkupLine("[bold dodgerblue1]To turn on debugging, use the command:[/][bold yellow] debug on[/]");
                    AnsiConsole.MarkupLine("[bold dodgerblue1]To turn off debugging, use the command:[/][bold yellow]  debug off[/]");
                }
                else if (parts[0] == "history")
                {
                    // show command history
                    if (commandHistory.Count > 0)
                    {
                        AnsiConsole.MarkupLine("[bold dodgerblue1]Command History:[/]");
                        foreach (var command in commandHistory)
                        {
                            AnsiConsole.WriteLine(command);
                        }
                    }
                    else
                    {
                        AnsiConsole.MarkupLine("[bold dodgerblue1]No command history.[/]");
                    }
                }
                else if (parts[0] == "connect")
                {

                    Configuration config = await LoadConfiguration();

                    // check to see if we are already connected, if so, disconnect first
                    if (connectionRSM != null)
                    {
                        await disconnect();
                    }

                    await AnsiConsole.Status()
                        .StartAsync("Connecting to " + config.Uri, async ctx =>
                        {
                            ctx.Spinner(Spinner.Known.Pong);
                            ctx.SpinnerStyle(Style.Parse("green"));

                            // create new connectionRSM
                            try
                            {
                                connectionRSM = new(config);
                            }
                            catch (Exception e)
                            {
                                AnsiConsole.WriteException(e);
                                return;
                            }
                            // Call the Connect State, to connect WebSockets
                            await HandleEvent(ConnectionRSM.Action.Connect, connectionRSM, null, null);

                            // If we are connected, then we can start bQueueActivated for events.
                            if (connectionRSM.stateRSM.connectionState == RSMStates.ConnectionConnected)
                            {

                                await Task.Delay(500);

                                await HandleEvent(ConnectionRSM.Action.SubscribeAgency, connectionRSM, RSMTestable.Testable.AgencySubscription, RSMStates.AgencySubscribed, 2000);
                                await HandleEvent(ConnectionRSM.Action.RegisterAgency, connectionRSM, RSMTestable.Testable.RegistrationState, RSMStates.AgencyRegistered, 2000);
                                await HandleEvent(ConnectionRSM.Action.SubscribeCalls, connectionRSM, RSMTestable.Testable.CallsSubscription, RSMStates.CallsSubscribed, 2000);

                                // AnsiConsole.MarkupLine("[bold dodgerblue1]Requesting Call Queue.[/]");
                                // await HandleEvent(ConnectionRSM.Action.CallQueueRequest, connectionRSM, RSMTestable.Testable.CallQueue, RSMStates.CallQueueRequested, 1000);

                                AnsiConsole.MarkupLine("[bold lime]Connected and ready to accept calls![/]");

                                RegisterEventHanlders();

                                // run our tasks
                                try
                                {

                                    processCallQueueTaskTokenSource = new();

                                    _ = Task.Run(() => ProcessQueue(), processCallQueueTaskTokenSource.Token);

                                }
                                catch (Exception e)
                                {
                                    AnsiConsole.WriteException(e);
                                }
                            }
                            else
                            {
                                AnsiConsole.MarkupLine("[bold red]Connection Failed[/]");
                            }
                        });
                }
                else if (parts[0] == "disconnect")
                {
                    await disconnect();
                }
                else if (parts[0] == "showConfig")
                {
                    // show current configuration
                    Configuration config = await LoadConfiguration();

                    // create a table
                    var table = new Table();
                    table.AddColumn("Setting");
                    table.AddColumn("Value");

                    table.AddRow("Uri", config.Uri ?? "");
                    table.AddRow("Username", config.Username ?? "");
                    table.AddRow("Password", config.Password ?? "");
                    table.AddRow("AgencyId", config.AgencyId ?? "");
                    table.AddRow("Secret", config.Secret ?? "");

                    AnsiConsole.Write(table);

                    AnsiConsole.WriteLine("To edit the configuration, use the command: editConfig");

                }
                else if (parts[0] == "editConfig")
                {
                    // edit configuration using AnsiConsole.Prompt
                    Configuration config = await LoadConfiguration();

                    config.Uri = AnsiConsole.Prompt(
                        new TextPrompt<string>("Enter Uri")
                            .DefaultValue(config.Uri ?? "ws://hackrtc.indigital.dev:8800/text-control-api/v3")
                    );

                    config.Username = AnsiConsole.Prompt(
                        new TextPrompt<string>("Enter Username")
                            .DefaultValue(config.Username ?? "")
                    );

                    config.Password = AnsiConsole.Prompt(
                        new TextPrompt<string>("Enter Password")
                            .DefaultValue(config.Password ?? "")
                    );

                    config.AgencyId = AnsiConsole.Prompt(
                        new TextPrompt<string>("Enter AgencyId")
                            .DefaultValue(config.AgencyId ?? "")
                    );

                    config.Secret = AnsiConsole.Prompt(
                        new TextPrompt<string>("Enter Secret")
                            .DefaultValue(config.Secret ?? "")
                    );

                    SaveConfiguration(config);

                    AnsiConsole.MarkupLine("[bold dodgerblue1]Configuration saved.[/]");
                }
                else if (parts[0] == "clearActiveCall")
                {
                    activeCallId = "";
                    AnsiConsole.MarkupLine("[bold dodgerblue1]Active Call Id cleared.[/]");
                }
                else if (parts[0] == "listCalls")
                {
                    if (connectionRSM == null)
                    {
                        AnsiConsole.MarkupLine("[bold red]Cannot run this command until connected.[/]");
                        continue;
                    }

                    if (connectionRSM.callQueue.Count == 0)
                    {
                        AnsiConsole.MarkupLine("[bold yellow]No calls in queue.[/]");
                        continue;
                    }

                    var callTable = new Table();
                    callTable.AddColumns("Call ID", "State", "Type", "Agent", "Ext. Party", "Queued", "Accepted", "Ended");

                    foreach (var call in connectionRSM.callQueue)
                    {
                        var c = call.Value.CallEvent;
                        if (c == null || c.CallId == null) continue;
                        callTable.AddRow(c.CallId, c.CallState ?? "", c.CallType ?? "", c.AgentIdentifier ?? "", c.EmergencyPartyIdentifier ?? "", c.QueuedDateTime ?? "", c.AcceptedDateTime ?? "", c.EndedDateTime ?? "");
                    }

                    AnsiConsole.Write(callTable);
                }
                else if (parts[0] == "purgeCalls")
                {
                    if (connectionRSM == null)
                    {
                        AnsiConsole.MarkupLine("[bold red]Cannot run this command until connected.[/]");
                        continue;
                    }

                    if (connectionRSM.callQueue.Count == 0)
                    {
                        AnsiConsole.MarkupLine("[bold dodgerblue1]No calls to purge.[/]");
                        continue;
                    }

                    foreach (var call in connectionRSM.callQueue)
                    {
                        var c = call.Value.CallEvent;
                        if (c == null) continue;
                        if (c.CallState == "ended" || c.CallState == "missed")
                        {
                            connectionRSM.callQueue.Remove(c.CallId);
                            AnsiConsole.MarkupLine($"[bold yellow]Purged call {c.CallId}[/]");
                        }
                    }
                }
                else if (parts[0] == "endCall")
                {
                    if (activeCallId == "")
                    {
                        AnsiConsole.MarkupLine("[bold red]No active call, cannot end call. Please set active call with `setActiveCall [[callId]]`[/]");
                        continue;
                    }
                    ConsoleInput consoleInput = new()
                    {
                        callId = activeCallId
                    };

                    if (connectionRSM == null)
                    {
                        AnsiConsole.MarkupLine("[bold red]Cannot run this command until connected.[/]");
                        continue;
                    }

                    await HandleEvent(ConnectionRSM.Action.EndCall, connectionRSM, null, consoleInput);
                    AnsiConsole.MarkupLine("[bold dodgerblue1]Ended call[/]");
                    activeCallId = "";

                    // remove from incomingCallList
                    if (incomingCallList.Contains(consoleInput.callId))
                    {
                        incomingCallList.Remove(consoleInput.callId);
                    }

                    // remove from messages
                    if (messages.ContainsKey(consoleInput.callId))
                    {
                        messages.Remove(consoleInput.callId);
                    }
                }
                else if (parts[0] == "acceptCall")
                {

                    try
                    {
                        if (connectionRSM == null)
                        {
                            AnsiConsole.MarkupLine("[bold red]Cannot run this command until connected.[/]");
                            continue;
                        }


                        if (incomingCallList.Count == 0)
                        {
                            // must of missed the call
                            AnsiConsole.MarkupLine("[bold red]No calls to accept.[/]");
                            continue;
                        }

                        // get first callId from incomingCallList
                        activeCallId = incomingCallList.First();

                        await HandleEvent(ConnectionRSM.Action.AcceptCall, connectionRSM, RSMTestable.Testable.CallQueue, RSMStates.CallAnswered, 1000);
                        AnsiConsole.MarkupLine($"\n[bold dodgerblue1]Accepted call {activeCallId}[/]");
                    }
                    catch (Exception)
                    {
                        AnsiConsole.MarkupLine("[bold red]Call not found.[/]\n");
                        continue;
                    }
                }
                else if (parts[0] == "showMessages")
                {
                    if (connectionRSM == null)
                    {
                        AnsiConsole.MarkupLine("[bold red]Cannot run this command until connected.[/]");
                        continue;
                    }
                    if (activeCallId.Length == 0)
                    {
                        AnsiConsole.MarkupLine("[bold yellow]No active call to show messages for. Please set active call with setActiveCall [[callId]][/]");
                        continue;
                    }

                    if (messages.ContainsKey(activeCallId))
                    {
                        var messageTable = new Table();
                        messageTable.AddColumns("From", "Message", "Date/Time");

                        foreach (var message in messages[activeCallId])
                        {
                            messageTable.AddRow(message.from ?? "", message.body ?? "", message.dateTime ?? "");
                        }

                        AnsiConsole.Write(messageTable);
                    }
                    else
                    {
                        AnsiConsole.MarkupLine("[bold dodgerblue1]No messages for this call.[/]");
                    }
                }
                else if (parts[0] == "help") AnsiConsole.MarkupLine(help);
                else
                {
                    if (activeCallId.Length > 0)
                    {
                        // in an active call, just send the message since it's not a command
                        await sendMessage();
                    }
                    else
                        AnsiConsole.MarkupLine("[bold red]Unknown command: [/]" + parts[0]);
                }
            }
            else if (parts.Length >= 2)
            {
                if (parts[0] == "setActiveCall")
                {
                    string callId = parts[1];

                    try
                    {
                        if (connectionRSM == null)
                        {
                            AnsiConsole.MarkupLine("[bold red]Cannot run this command until connected.[/]");
                            continue;
                        }
                        var call = connectionRSM.callQueue[callId];

                        if (call == null)
                        {
                            AnsiConsole.MarkupLine("[bold red]Call not found.[/]");
                            continue;
                        }
                        else
                        {

                            if (call.CallEvent?.CallState is "ended" or "missed")
                            {
                                AnsiConsole.MarkupLine("[bold red]Call has ended or was missed.[/]");
                                continue;
                            }
                            else
                            {
                                activeCallId = callId;
                                AnsiConsole.MarkupLine("[bold dodgerblue1]Active Call Id set to " + activeCallId + "[/]");
                            }
                        }
                    }
                    catch (Exception)
                    {
                        AnsiConsole.MarkupLine("[bold red]Call not found.[/]");
                        continue;
                    }
                }
                else if (parts[0] == "endCall")
                {
                    string callId = parts[1];

                    if (callId.Length == 0 && activeCallId.Length == 0)
                    {
                        AnsiConsole.MarkupLine("[bold red]No active call, cannot end call. Please set active call with setActiveCall [[callId]][/]");
                        continue;
                    }

                    if (connectionRSM == null)
                    {
                        AnsiConsole.MarkupLine("[bold red]Cannot run this command until connected.[/]");
                        continue;
                    }

                    ConsoleInput consoleInput = new()
                    {
                        callId = callId
                    };
                    await HandleEvent(ConnectionRSM.Action.EndCall, connectionRSM, null, consoleInput);
                    activeCallId = "";

                    // remove from incomingCallList
                    if (incomingCallList.Contains(consoleInput.callId))
                    {
                        incomingCallList.Remove(consoleInput.callId);
                    }

                    // remove from messages
                    if (messages.ContainsKey(consoleInput.callId))
                    {
                        messages.Remove(consoleInput.callId);
                    }
                }
                else if (parts[0] == "debug")
                {
                    if (parts[1] == "on") { DebuggingEnabled = true; AnsiConsole.MarkupLine($"[bold dodgerblue1]Debugging enabled[/]\n[bold grey]{DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss.fff tt")} - example debugger log[/]"); }
                    else if (parts[1] == "off") { DebuggingEnabled = false; AnsiConsole.MarkupLine("[bold dodgerblue1]Debugging disabled[/]"); }
                    else AnsiConsole.MarkupLine("[bold red]Values can only be \"on\" or \"off\"[/]");
                }
                else if (parts[0] == "showMessages")
                {
                    if (connectionRSM == null)
                    {
                        AnsiConsole.MarkupLine("[bold red]Cannot run this command until connected.[/]");
                        continue;
                    }

                    if (parts[1].Length == 0)
                    {
                        AnsiConsole.MarkupLine("[bold red]No callId specified.[/]");
                        continue;
                    }

                    if (messages.ContainsKey(parts[1]))
                    {
                        var messageTable = new Table();
                        messageTable.AddColumns("From", "Message", "Date/Time");

                        foreach (var message in messages[parts[1]])
                        {
                            messageTable.AddRow(message.from ?? "", message.body ?? "", message.dateTime ?? "");
                        }

                        AnsiConsole.Write(messageTable);
                    }
                    else
                    {
                        AnsiConsole.MarkupLine("[bold dodgerblue1]No messages for this call.[/]");
                    }
                }
                else
                {
                    if (activeCallId.Length > 0)
                    {
                        // in an active call, just send the message since it's not a command
                        await sendMessage();
                    }
                    else
                        AnsiConsole.MarkupLine("[bold red]Unknown command: [/]" + parts[0]);
                }
            }
        }
    }

    public static void RegisterEventHanlders()
    {
        try
        {
            if (connectionRSM == null)
            {
                return;
            }

            connectionRSM.MessageReceivedEvent += (sender, e) =>
            {
                if (e.callId == null) return;

                // add message to messages dictionary
                if (messages.ContainsKey(e.callId))
                {
                    messages[e.callId].Add(e);
                }
                else
                {
                    messages.Add(e.callId, new List<Events.Message>() { e });
                }

                var body = "[bold dodgerblue1]Message Received [/][lime]:down_left_arrow:[/][bold dodgerblue1] - [/][bold yellow]" + e.body + "[/]";

                if (!string.IsNullOrEmpty(activeCallId) && e.callId == activeCallId)
                    AnsiConsole.MarkupLine("\n" + body);
                else
                    AnsiConsole.MarkupLine("\n[bold red](" + e.callId + ")[/]" + body);
                DisplayPrompt();
                Console.Beep();
            };
            connectionRSM.LocationReceivedEvent += (sender, e) =>
            {
                if (activeCallId.Length > 0)
                    AnsiConsole.MarkupLine("\n[bold dodgerblue1]Location Received: [/][yellow]" + e.latitude + ", " + e.longitude + "[/]");
                else
                    AnsiConsole.MarkupLine("\n[bold dodgerblue1]Location Received (" + e.callId + "):[/] [yellow]" + e.latitude + ", " + e.longitude + "[/]");

                // create a link to google maps with the location coordinates and make it clickable in the console
                string link = "https://maps.google.com/?q=" + e.latitude + "," + e.longitude;
                AnsiConsole.MarkupLine($"[bold yellow]Google maps link: [/][underline blue link={link}]{link}[/]");
                DisplayPrompt();
                Console.Beep();
            };
        }
        catch (Exception e)
        {
            AnsiConsole.WriteException(e);
        }
    }

    public static async Task ProcessQueue()
    {

        // were we already cancelled?
        processCallQueueTaskTokenSource.Token.ThrowIfCancellationRequested();

        if (DebuggingEnabled)
            AnsiConsole.MarkupLine($"[bold grey]{DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss.fff tt")} - Entering in outer loop for ProcessQueue Action[/]");

        while (true)
        {

            if (processCallQueueTaskTokenSource.Token.IsCancellationRequested)
            {
                processCallQueueTaskTokenSource.Token.ThrowIfCancellationRequested();
                break;
            }

            if (connectionRSM == null) continue;

            //If we are in the CallPresented state, then we are ready to answer a call. 
            if (connectionRSM.stateRSM.callQueueState == RSMStates.CallPresented)
            {

                List<IncomingQueuedCall> incomingCalls = connectionRSM.callQueue.Values.Where(x => x.CallsState == IncomingQueuedCall.CallState.Presented).ToList();

                foreach (var incomingCall in incomingCalls)
                {
                    if (incomingCall.CallEvent != null && !incomingCallList.Contains(incomingCall.CallEvent.CallId))
                    {
                        AnsiConsole.WriteLine();
                        AnsiConsole.WriteLine();
                        AnsiConsole.Write(new Rule("Incoming Call - Type acceptCall to answer").RuleStyle("lime"));
                        AnsiConsole.MarkupLine($"[bold lime]Call Id: [/][bold yellow]{incomingCall.CallEvent.CallId}[/]");
                        AnsiConsole.MarkupLine($"[bold lime]From: [/][bold yellow]{incomingCall.CallEvent.EmergencyPartyIdentifier}[/]");
                        AnsiConsole.Write(new Rule().RuleStyle("lime"));
                        DisplayPrompt();
                        Console.Beep();
                        incomingCallList.Add(incomingCall.CallEvent.CallId);
                    }
                }
            }
            else if (connectionRSM.stateRSM.callQueueState == RSMStates.ProcessQueue)
            {
                if (incomingCallList.Count > 0)
                {
                    // loop thru and see if calls need to be removed from list
                    foreach (var call in connectionRSM.callQueue)
                    {
                        if (call.Value.CallEvent != null)
                        {
                            if (call.Value.CallEvent.CallState != "presented" && incomingCallList.Contains(call.Value.CallEvent.CallId))
                            {
                                // remove from list
                                incomingCallList.Remove(call.Value.CallEvent.CallId);
                            }
                            else if (call.Value.CallEvent.CallState == "presented")
                            {
                                // The current state is ProccessQueue, we need to change to CallPresented
                                connectionRSM.stateRSM.callQueueState = RSMStates.CallPresented;
                            }
                        }
                    }
                }
            }

            await HandleEvent(ConnectionRSM.Action.ProcessQueue, connectionRSM, RSMTestable.Testable.CallQueue, RSMStates.CallPresented, 1000);
            await Task.Delay(1000);
        }
    }
}
