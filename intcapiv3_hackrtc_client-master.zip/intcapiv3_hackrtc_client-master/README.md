# INTCAPI Console App

This console app was created to show one of the many ways you can code towards INTCAPI v3. The main console application lives within the `Program.cs` file. All the other files prefixed with `INTCAPIv3` are what it involves for this style of application to connect, receive calls, answer calls, send and receive text messages and receive location.

The `commandHistory.txt` and `config.json` files are used by the Console Application for history of commands and the configuration used to connect to INTCAPI. You are able to delete them and they will be recreated by the program.

# Getting started

This Console Application depends on .NET 6 runtime. There are many ways to install .NET onto your machine but I'd advise to go here to install it for your OS: https://learn.microsoft.com/en-us/dotnet/core/install/

Once .NET 6 is installed, you can run the application by typing this into your console: `dotnet run`

## Console Program

### First run & startup

The first thing you'll want to do is type `help` to see a list of what commands that can be run. You'll notice the `connect` & `disconnect` commands. This is how you connect and disconnect from INTCAPI. But before you can connect, you'll need to enter in some configuration for connecting.

Type in `editConfig` and hit enter. Follow the step-by-step wizard, entering in your configuration for WebSocket URI, Agency ID, Secret, Username and Password. Once done, you can now run the `connect` command.

To see your configuration, type `showConfig`.

### Incoming calls & Messaging

When an incoming call comes in, you will type `acceptCall` to answer it. Each call is answered in the order it was received. From here, you are dropped into the call. You will receive a message from the caller and a location if there is one. In order to message back, simply just type out what you want to say and hit enter.

To see all messages, type `showMessages`.

### Switching between accepted calls

To switch between calls, type `setActiveCall` followed by the Call ID to switch to. To reset the programs focus, type `clearActiveCall`.

### Ending a call

When in a session with a caller, you can simply type `endCall` to end the currently active call you are on. To end a different call, simply type `endCall` followed by the Call ID.

### What's in the queue?

To see what's in the queue, type `listCalls`. Here you will see all the calls in the queue. To remove missed and ended calls, type `purgeCalls`.

### Debugging

To enable debugging, type `debug on`. To see what state your debugging is in, type `debug`. To disable debugging, type `debug off`. Debugging is off by default.
