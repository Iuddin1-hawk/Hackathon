﻿using System.Text;
using System.Net.WebSockets;
using Spectre.Console;
using static INTCAPI.ConnectionRSM;

namespace INTCAPI;

public class WebSocketClient
{
    public ClientWebSocket? _webSocket;

    public void Dispose()
    {
        _webSocket?.Dispose();
        GC.SuppressFinalize(this);
    }

    public async Task ConnectAsync(string url, string username, string password, CancellationToken cancellationToken)
    {
        _webSocket = new ClientWebSocket();
        string authToken = Convert.ToBase64String(Encoding.ASCII.GetBytes($"{username}:{password}"));
        _webSocket.Options.SetRequestHeader("Authorization", $"Basic {authToken}");

        try
        {
            await _webSocket.ConnectAsync(new Uri(url), cancellationToken);
        }
        catch (Exception ex)
        {
            AnsiConsole.WriteException(ex);
        }
    }

    // Disconnect
    public async Task DisconnectAsync(CancellationToken cancellationToken)
    {
        if (_webSocket != null)
        {
            try
            {
                await _webSocket.CloseAsync(WebSocketCloseStatus.NormalClosure, "Normal closure", cancellationToken);
            }
            catch (Exception)
            { }
        }
    }

    // Subscribe to Agency Events
    public async Task SubscribeToAgencyActionAsync(string agencyIdentifier, string secret, ConnectionRSM connectionFSM, string correlationId, CancellationToken cancellationToken)
    {
        var request = new
        {
            action = "subscribe",
            correlationId,
            agencyIdentifier,
            secret
        };

        await SendMessageAsync(request, cancellationToken);
    }

    // Register the Agency
    public async Task RegisterAgencyActionAsync(string agencyIdentifier, string secret, ConnectionRSM connectionFSM, string correlationId, CancellationToken cancellationToken)
    {

        var request = new
        {
            action = "registerAgency",
            correlationId,
            agencyIdentifier,
            secret,
            maintenanceMode = false
        };

        await SendMessageAsync(request, cancellationToken);
    }
    // Accept the call
    public async Task AcceptCallActionAsync(ConnectionRSM connectionFSM, string correlationId, string callId, CancellationToken cancellationToken)
    {
        // Example
        //"action": "acceptCall",
        //"correlationId": "acpt1",
        //"registerToken": "4372c052-fddb-4e27-979d-0b863e5eaca3",
        //"callId": "dbgot6tnoohdgfsbl3j8",
        //"agentIdentifier": "Agent 1"

        var request = new
        {
            action = "acceptCall",
            correlationId,
            registerToken = connectionFSM.registerToken,
            callId,
            agentIdentifier = "me"
        };

        await SendMessageAsync(request, cancellationToken);
    }
    public async Task SubscribeToCallsActionAsync(ConnectionRSM connectionFSM, string correlationId, CancellationToken cancellationToken)
    {

        var request = new
        {
            action = "subscribe",
            correlationId,
            registerToken = connectionFSM.registerToken
        };

        await SendMessageAsync(request, cancellationToken);
    }
    public async Task UnregisterAgencyActionAsync(string registerToken, CancellationToken cancellationToken)
    {
        var request = new
        {
            action = "unregisterAgency",
            correlationId = Guid.NewGuid().ToString(),
            registerToken
        };
        await SendMessageAsync(request, cancellationToken);
    }

    public async Task RequestAgencyInfoActionAsync(string agencyIdentifier, string secret, CancellationToken cancellationToken)
    {
        var request = new
        {
            action = "requestAgencyInfo",
            correlationId = Guid.NewGuid().ToString(),
            agencyIdentifier,
            secret
        };
        await SendMessageAsync(request, cancellationToken);
    }

    // After getting token... Subscribe to Call events
    public async Task SubscribeToCallEventsAsync(string registerToken, CancellationToken cancellationToken)
    {
        var request = new
        {
            action = "subscribe",
            correlationId = Guid.NewGuid().ToString(),
            registerToken
        };
        await SendMessageAsync(request, cancellationToken);
    }

    public async Task EndCallActionAsync(ConnectionRSM connectionFSM, string callId, string body, CancellationToken cancellationToken)
    {
        var request = new
        {
            action = "endCall",
            correlationId = Guid.NewGuid().ToString(),
            registerToken = connectionFSM.registerToken,
            callId,
            body
        };
        await SendMessageAsync(request, cancellationToken);
    }

    public async Task AcceptCallActionAsync(string registerToken, string callId, string AgentIdentifier, CancellationToken cancellationToken)
    {
        var request = new
        {
            action = "acceptCall",
            correlationId = Guid.NewGuid().ToString(),
            registerToken,
            callId,
            AgentIdentifier
        };
        await SendMessageAsync(request, cancellationToken);
    }

    public async Task StartCallActionAsync(string registerToken, string uri, string body, string agentIdentifier, CancellationToken cancellationToken)
    {
        var request = new
        {
            action = "startCall",
            correlationId = Guid.NewGuid().ToString(),
            registerToken,
            uri,
            body,
            agentIdentifier
        };
        await SendMessageAsync(request, cancellationToken);
    }

    public async Task RejectCallActionAsync(string registerToken, string callId, CancellationToken cancellationToken)
    {
        var request = new
        {
            action = "rejectCall",
            correlationId = Guid.NewGuid().ToString(),
            registerToken,
            callId
        };
        await SendMessageAsync(request, cancellationToken);
    }

    public async Task SendMessageActionAsync(ConnectionRSM connectionFSM, string callId, string body, CancellationToken cancellationToken)
    {
        var request = new
        {
            action = "sendMessage",
            correlationId = Guid.NewGuid().ToString(),
            registerToken = connectionFSM.registerToken,
            callId,
            body
        };
        await SendMessageAsync(request, cancellationToken);
    }

    public async Task SendPrivateMessageActionAsync(string registerToken, string callId, string body, string to, CancellationToken cancellationToken)
    {
        var request = new
        {
            action = "sendMessage",
            correlationId = Guid.NewGuid().ToString(),
            registerToken,
            callId,
            body,
            to
        };
        await SendMessageAsync(request, cancellationToken);
    }

    public async Task SendQueryLocationActionAsync(string registerToken, string callId, string locationType, CancellationToken cancellationToken)
    {
        var request = new
        {
            action = "queryLocation",
            correlationId = Guid.NewGuid().ToString(),
            registerToken,
            callId,
            locationType
        };
        await SendMessageAsync(request, cancellationToken);
    }
    public async Task SendRequestCallInfoActionAsync(string registerToken, string callId, CancellationToken cancellationToken)
    {
        var request = new
        {
            action = "requestCallInfo",
            correlationId = Guid.NewGuid().ToString(),
            registerToken,
            callId
        };
        await SendMessageAsync(request, cancellationToken);
    }

    public async Task SendRequestCallQueueActionAsync(ConnectionRSM connectionFSM, CancellationToken cancellationToken)
    {
        var request = new
        {
            action = "requestCallQueue",
            correlationId = Guid.NewGuid().ToString(),
            registerToken = connectionFSM.registerToken
        };
        await SendMessageAsync(request, cancellationToken);
    }

    // General SendMessage used by the above Subscriptions and Actions.
    private async Task SendMessageAsync(object message, CancellationToken cancellationToken)
    {
        var payload = Newtonsoft.Json.JsonConvert.SerializeObject(message);
        var buffer = System.Text.Encoding.UTF8.GetBytes(payload);
        var segment = new ArraySegment<byte>(buffer);

        if (DebuggingEnabled) AnsiConsole.MarkupLineInterpolated($"[bold grey]{DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss.fff tt")} - SendMessageAsync: [/][turquoise2]{payload}[/]");

        // if _webSocket is null, throw an exception
        if (_webSocket == null)
        {
            throw new Exception("WebSocket is null");
        }

        await _webSocket.SendAsync(segment, WebSocketMessageType.Text, true, cancellationToken);
    }
    public static async Task ListenForIncomingEventsAsync(WebSocketClient webSocketClient, ConnectionRSM connectionRSM, CancellationToken cancellationToken)
    {

        // if _webSocket is null, throw an exception
        if (webSocketClient._webSocket == null)
        {
            throw new Exception("WebSocket is null");
        }

        if (DebuggingEnabled) AnsiConsole.MarkupLine($"[bold grey]{DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss.fff tt")} - ListenForIncomingEventsAsync: Listening for incoming events.[/]");

        ClientWebSocket _webSocket = webSocketClient._webSocket;
        string continuationPayload = "";
        int bufferSize = 2048;
        while (!cancellationToken.IsCancellationRequested)
        {
            var buffer = new ArraySegment<byte>(new byte[bufferSize]);
            var result = await _webSocket.ReceiveAsync(buffer, cancellationToken);

            //Add a test for buffer not being empty
            if (buffer.Count() == 0)
            {
                if (DebuggingEnabled) AnsiConsole.MarkupLine($"[bold grey]{DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss.fff tt")} - ListenForIncomingEventsAsync: Buffer is empty, breaking from loop;[/]");
                break;
            }
            if (result.MessageType == WebSocketMessageType.Close)
            {
                if (DebuggingEnabled) AnsiConsole.MarkupLine($"[bold grey]{DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss.fff tt")} - ListenForIncomingEventsAsync: WebSocketMessageType.Close, breaking from loop;[/]");
                await _webSocket.CloseAsync(WebSocketCloseStatus.NormalClosure, string.Empty, cancellationToken);
                break;
            }

            // check to see if buffer.Array is null, if so, break from loop
            if (buffer.Array == null)
            {
                if (DebuggingEnabled) AnsiConsole.MarkupLine($"[bold grey]{DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss.fff tt")} - ListenForIncomingEventsAsync: Buffer.Array is null, breaking from loop;[/]");
                break;
            }

            var payload = System.Text.Encoding.UTF8.GetString(buffer.Array, 0, result.Count);
            var eventMessage = new GenericEventMessage();
            try
            {
                if (continuationPayload.Length > 0)
                {
                    payload = continuationPayload + payload;
                    continuationPayload = "";
                }

                eventMessage = Newtonsoft.Json.JsonConvert.DeserializeObject<GenericEventMessage>(payload); // Need a generic eventMessage to find the event code and correlationId if present.
            }
            catch (Exception)
            {
                if (buffer.Count() == bufferSize)
                {
                    if (DebuggingEnabled) AnsiConsole.MarkupLine($"[bold grey]{DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss.fff tt")} - ListenForIncomingEventsAsync: Message cannot be deserialized however the buffer is full. Setting continuation flag.[/]");

                    // deserialize failed, we need to keep reading in the buffer
                    continuationPayload += payload;
                }
                else
                {
                    if (DebuggingEnabled) AnsiConsole.MarkupLine($"[bold grey]{DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss.fff tt")} - ListenForIncomingEventsAsync: Message cannot be deserialized and the buffer count is not full. Breaking from loop;[/]");
                    break;
                }
            }

            if (eventMessage == null)
            {
                if (DebuggingEnabled) AnsiConsole.MarkupLine($"[bold grey]{DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss.fff tt")} - ListenForIncomingEventsAsync: EventMessage is null, breaking from loop;[/]");
                break;
            }

            //check to see if payload is not null
            if (payload == null)
            {
                if (DebuggingEnabled) AnsiConsole.MarkupLine($"[bold grey]{DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss.fff tt")} - ListenForIncomingEventsAsync: Payload is null, breaking from loop;[/]");
                break;
            }

            if (DebuggingEnabled)
            {
                AnsiConsole.MarkupLineInterpolated($"[bold grey]{DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss.fff tt")} - ListenForIncomingEventsAsync: [/][yellow]{payload}[/]");
            }


            CallEventMessage? callEventMessage;
            switch (eventMessage.Event)
            {
                case "response": //Generic response event used by actions.

                    var responseMessage = Newtonsoft.Json.JsonConvert.DeserializeObject<ResponseMessage>(payload); //Since we know we have a response, now we need a ResponseMessage from the payload
                    dynamic? joMessage = Newtonsoft.Json.JsonConvert.DeserializeObject(payload); //Hack to test for correlationId

                    //Make sure that responseMessage and joMessage are not null and break if either are.
                    if (responseMessage == null)
                    {
                        if (DebuggingEnabled) AnsiConsole.MarkupLine($"[bold grey]{DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss.fff tt")} - ListenForIncomingEventsAsync: Message is not a response message, breaking from loop; payload: {payload}[/]");
                        break;
                    }
                    if (joMessage == null)
                    {
                        if (DebuggingEnabled) AnsiConsole.MarkupLine($"[bold grey]{DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss.fff tt")} - ListenForIncomingEventsAsync: Message cannot be deserialized, breaking from loop; payload: {payload}[/]");
                        break;
                    }

                    //int responseStatusCode;
                    if (responseMessage.ResponseStatusCode == 200)
                    {
                        if (joMessage.ContainsKey("correlationId")) //Hack to test for correlationId
                        {
                            if (joMessage.callQueue != null)
                            {

                                CallQueueResponse? callQueueResponse = Newtonsoft.Json.JsonConvert.DeserializeObject<CallQueueResponse>(payload);
                                if (callQueueResponse == null)
                                {
                                    if (DebuggingEnabled) AnsiConsole.MarkupLine($"[bold grey]{DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss.fff tt")} - ListenForIncomingEventsAsync: Message is not a callQueueResponse message, breaking from loop; payload: {payload}[/]");
                                    break;
                                }
                                if (callQueueResponse.Call != null)
                                {
                                    foreach (CallEventMessage call in callQueueResponse.Call)
                                    {
                                        if (DebuggingEnabled) AnsiConsole.MarkupLine($"[bold grey]{DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss.fff tt")} - ListenForIncomingEventsAsync: Recieved Incoming call Event {call.Event}[/]");
                                        await HandleCallEventAsync(call, connectionRSM, cancellationToken);
                                    }
                                }
                                if (callQueueResponse.Messages != null)
                                {
                                    foreach (MessageEvent message in callQueueResponse.Messages)
                                    {
                                        if (DebuggingEnabled) AnsiConsole.MarkupLine($"[bold grey]{DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss.fff tt")} - ListenForIncomingEventsAsync: Recieved Incoming message Event {message.Event}[/]");
                                        await HandleMessageEventAsync(message, connectionRSM, cancellationToken);
                                    }
                                }
                                if (callQueueResponse.Locations != null)
                                {
                                    foreach (LocationEvent location in callQueueResponse.Locations)
                                    {
                                        if (DebuggingEnabled) AnsiConsole.MarkupLine($"[bold grey]{DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss.fff tt")} - ListenForIncomingEventsAsync: Recieved Incoming location Event {location.Event}[/]");
                                        await HandleLocationEventAsync(location, connectionRSM, cancellationToken);
                                    }
                                }
                            }
                            else
                            {
                                await HandleEvent(null, connectionRSM, responseMessage, null); // Handle the response event
                            }
                        }
                    }
                    break;
                case "callPresented":

                    if (payload == null)
                    {
                        if (DebuggingEnabled) AnsiConsole.MarkupLine($"[bold grey]{DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss.fff tt")} - ListenForIncomingEventsAsync: CallPresented payload is null. Breaking from loop.[/]");
                        break;
                    }
                    // AnsiConsole.MarkupLine($"[bold grey]{DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss.fff tt")} - ListenForIncomingEventsAsync: Recieved Incoming callPresented Event {payload}[/]");
                    callEventMessage = Newtonsoft.Json.JsonConvert.DeserializeObject<CallEventMessage>(payload);
                    if (callEventMessage == null)
                    {
                        if (DebuggingEnabled) AnsiConsole.MarkupLine($"[bold grey]{DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss.fff tt")} - ListenForIncomingEventsAsync: CallEventMessage is null. Breaking from loop.[/]");
                        break;
                    }
                    await HandleCallEventAsync(callEventMessage, connectionRSM, cancellationToken);
                    break;
                case "callEnded":
                    if (payload == null)
                    {
                        if (DebuggingEnabled) AnsiConsole.MarkupLine($"[bold grey]{DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss.fff tt")} - ListenForIncomingEventsAsync: CallEnded has no payload. Breaking from loop.[/]");
                        break;
                    }
                    // AnsiConsole.MarkupLine($"[bold grey]{DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss.fff tt")} - ListenForIncomingEventsAsync: Recieved Incoming callPresented Event {payload}[/]");
                    callEventMessage = Newtonsoft.Json.JsonConvert.DeserializeObject<CallEventMessage>(payload);
                    if (callEventMessage == null)
                    {
                        if (DebuggingEnabled) AnsiConsole.MarkupLine($"[bold grey]{DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss.fff tt")} - ListenForIncomingEventsAsync: CallEventMessage is null. Breaking from loop.[/]");
                        break;
                    }
                    await HandleCallEventAsync(callEventMessage, connectionRSM, cancellationToken);
                    break;
                case "callMissed":
                    if (payload == null)
                    {
                        if (DebuggingEnabled) AnsiConsole.MarkupLine($"[bold grey]{DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss.fff tt")} - ListenForIncomingEventsAsync: CallMissed has no payload. Breaking from loop.[/]");
                        break;
                    }
                    // AnsiConsole.MarkupLine($"[bold grey]{DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss.fff tt")} - ListenForIncomingEventsAsync: Recieved Incoming callPresented Event {payload}[/]");
                    callEventMessage = Newtonsoft.Json.JsonConvert.DeserializeObject<CallEventMessage>(payload);
                    if (callEventMessage == null)
                    {
                        if (DebuggingEnabled) AnsiConsole.MarkupLine($"[bold grey]{DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss.fff tt")} - ListenForIncomingEventsAsync: CallEventMessage is null. Breaking from loop.[/]");
                        break;
                    }
                    await HandleCallEventAsync(callEventMessage, connectionRSM, cancellationToken);
                    break;
                case "callAccepted":
                    if (payload == null)
                    {
                        if (DebuggingEnabled) AnsiConsole.MarkupLine($"[bold grey]{DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss.fff tt")} - ListenForIncomingEventsAsync: CallAccepted has no payload. Breaking from loop.[/]");
                        break;
                    }
                    // AnsiConsole.MarkupLine($"[bold grey]{DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss.fff tt")} - ListenForIncomingEventsAsync: Recieved Incoming callPresented Event {payload}[/]");
                    callEventMessage = Newtonsoft.Json.JsonConvert.DeserializeObject<CallEventMessage>(payload);
                    if (callEventMessage == null)
                    {
                        if (DebuggingEnabled) AnsiConsole.MarkupLine($"[bold grey]{DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss.fff tt")} - ListenForIncomingEventsAsync: CallEventMessage is null. Breaking from loop.[/]");
                        break;
                    }
                    await HandleCallEventAsync(callEventMessage, connectionRSM, cancellationToken);
                    break;
                case "messageReceived":

                    if (payload == null)
                    {
                        if (DebuggingEnabled) AnsiConsole.MarkupLine($"[bold grey]{DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss.fff tt")} - ListenForIncomingEventsAsync: MessageReceived has no payload. Breaking from loop.[/]");
                        break;
                    }

                    try
                    {
                        var messageEventMessage = Newtonsoft.Json.JsonConvert.DeserializeObject<MessageEvent>(payload);
                        if (messageEventMessage == null)
                        {
                            if (DebuggingEnabled) AnsiConsole.MarkupLine($"[bold grey]{DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss.fff tt")} - ListenForIncomingEventsAsync: MessageReceived has not payload. Breaking from loop[/]");
                            break;
                        }

                        // print out the message body
                        await HandleMessageEventAsync(messageEventMessage, connectionRSM, cancellationToken);
                        break;
                    }
                    catch (Exception e)
                    {
                        AnsiConsole.WriteException(e);
                        break;
                    }
                case "location":
                    if (payload == null)
                    {
                        break;
                    }

                    try
                    {
                        var locationEvent = Newtonsoft.Json.JsonConvert.DeserializeObject<LocationEvent>(payload);
                        if (locationEvent == null)
                        {
                            break;
                        }

                        await HandleLocationEventAsync(locationEvent, connectionRSM, cancellationToken);
                        break;
                    }
                    catch (Exception e)
                    {
                        AnsiConsole.WriteException(e);
                        break;
                    }
            }
        }
    }
}

public class GenericEventMessage
{
#pragma warning disable CS8618 // Non-nullable field must contain a non-null value when exiting constructor. Consider declaring as nullable.
    public string Event { get; set; }
#pragma warning restore CS8618 // Non-nullable field must contain a non-null value when exiting constructor. Consider declaring as nullable.
    public string? CorrelationId { get; set; }

    public string? CallId { get; set; }
}
public class ResponseMessage : GenericEventMessage
{
    public int ResponseStatusCode { get; set; }
#pragma warning disable CS8618 // Non-nullable field must contain a non-null value when exiting constructor. Consider declaring as nullable.
    public string ResponseStatusMessage { get; set; }
#pragma warning restore CS8618 // Non-nullable field must contain a non-null value when exiting constructor. Consider declaring as nullable.
    public string? RegisterToken { get; set; }
    public string[]? TranslationLanguageSupport { get; set; }

    public CallQueueResponse? CallQueue { get; set; }
}

public class CallQueueResponse
{
    public List<CallEventMessage>? Call { get; set; }
    public List<MessageEvent>? Messages { get; set; }
    public List<LocationEvent>? Locations { get; set; }
}

public class Call
{
#pragma warning disable CS8618 // Non-nullable field must contain a non-null value when exiting constructor. Consider declaring as nullable.
    public string CallId { get; set; }
    public string AgentIdentifier { get; set; }
    public string CallState { get; set; }//",//:"presented"
    public string CallType { get; set; }//":"inbound",
#pragma warning restore CS8618 // Non-nullable field must contain a non-null value when exiting constructor. Consider declaring as nullable.
    public string? EmergencyPartyIdentifier { get; set; }//":"(260) 998-0000 <tel:+1-260-998-0000>",
    public string? QueuedDateTime { get; set; }//":"2023-07-18T13:41:50.146Z",
    public string? AcceptedDateTime { get; set; }//":null,
    public string? EndedDateTime { get; set; }//":null}
}
public class Message
{
#pragma warning disable CS8618 // Non-nullable field must contain a non-null value when exiting constructor. Consider declaring as nullable.
    public string MessageId { get; set; }
    public string From { get; set; }
    public string To { get; set; }
    public string Body { get; set; }
    public string DateTime { get; set; }
    public string BodyContentType { get; set; }
}
#pragma warning disable CS8618 // Non-nullable field must contain a non-null value when exiting constructor. Consider declaring as nullable.

public class Location
{
    public string LocationId { get; set; }
    public string LocationType { get; set; }
    public LocationInfo LocationInfo { get; set; }
    public string DateTime { get; set; }
}

public class LocationInfo
{
    public string Latitude { get; set; }
    public string Longitude { get; set; }
    public string Elevation { get; set; }
}

public class CallEventMessage : GenericEventMessage
{
    public Call Call { get; set; }
}

public class MessageEvent : GenericEventMessage
{
    public Message Message { get; set; }
}

public class LocationEvent : GenericEventMessage
{
    public Location Location { get; set; }
}

public class CallPresentedEvent
{
    public string Trigger { get; set; }
}
#pragma warning restore CS8618 // Non-nullable field must contain a non-null value when exiting constructor. Consider declaring as nullable.
