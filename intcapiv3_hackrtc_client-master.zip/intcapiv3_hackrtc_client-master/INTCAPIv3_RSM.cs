using System.Net.WebSockets;
using Spectre.Console;
using static INTCAPI.ConnectionRSM;
using static INTCAPI.Program;

namespace INTCAPI
{

    public class RSMTestable // Create a testable set of states that can be used throughout the async RSM
    {
        public enum Testable
        {
            Connection, // Connection Oriented States
            AgencySubscription, // Agency Oriented States
            RegistrationState, // Registration Oriented States
            CallsSubscription, // Call Subscpription Oriented States
            CallQueue, // Call Queue Oriented States
            ReceiveQueue // Message Queue Oriented States
        }

        // Define the current state variables
        public RSMStates connectionState = new();
        public RSMStates agencySubscriptionState = new();
        public RSMStates callsSubscriptionState = new();
        public RSMStates registrationState = new();
        public RSMStates callQueueState = new();
        public RSMStates receivedQueueState = new();

        public object? ReturnTestable(Testable testable)
        {
            return testable switch // Find the state that is being tested and return it.
            {
                Testable.Connection => connectionState,
                Testable.AgencySubscription => agencySubscriptionState,
                Testable.RegistrationState => registrationState,
                Testable.CallsSubscription => callsSubscriptionState,
                Testable.CallQueue => callQueueState,
                Testable.ReceiveQueue => receivedQueueState,
                _ => null,
            };
        }
        // Constructor to initialize the RSM variables with initial states
        public RSMTestable()
        {
            connectionState = RSMStates.ConnectionDisconnected;
            agencySubscriptionState = RSMStates.AgencyUnsubscribed;
            callsSubscriptionState = RSMStates.CallsUnsubscribed;
            registrationState = RSMStates.AgencyNotRegistered;
            callQueueState = RSMStates.QueueIdle;
        }

    }

    // Reaction State Machine, used to handle the state of the connection and the actions taken on it.
    public class ConnectionRSM
    {
        public static bool DebuggingEnabled
        {
            get => bDebug;
            set => bDebug = value;
        }

        // get connection state as a string
        public string GetConnectionState()
        {
            return stateRSM.connectionState.ToString();
        }

        public string? registerToken; // The registerToken is provided back once the agency registers with INTCAPI. This variable keeps the current one.

        public enum Action
        {
            // Connection Oriented States
            Connect,
            Disconnect,
            // Agency Oriented Actions
            SubscribeAgency,
            AgencySubscribed,
            UnsubscribeAgency,
            RegisterAgency,
            AgencyRegistered,
            UnregisterAgency,
            // Calls Oriented Actions
            SubscribeCalls,
            CallsSubscribed,
            // Call Oriented Actions
            CallPresented,
            ProcessQueue,
            AcceptCall,
            RejectCall,
            EndCall,
            SendMessage,
            ReceiveMessage,
            ReceiveLocation,
            CallEnded,
            CallAccepted,
            CallMissed,
            CallQueueRequest
        }

        // Define the possible states of the RSM
        public enum RSMStates
        {
            ConnectionDisconnected,
            ConnectionConnected,
            ConnectionLost,
            // Agency Oriented States
            AgencySubscribing,
            AgencyUnsubscribed,
            AgencySubscribed,
            AgencyRegistering,
            AgencyNotRegistered,
            AgencyRegistered,
            // Calls Oriented States
            CallsSubscribing,
            CallsUnsubscribed,
            CallsSubscribed,
            CallQueueRequested,
            // Call Oriented States
            ProcessQueue,
            QueueIdle,
            CallPresented,
            CallAnswering,
            CallAnswered,
            CallEnded
        }
        public enum CallState
        {
            Presented,
            Answered,
            Ended
        }
        public enum CallQueueState
        {
            Empty,
            Queued
        }

        public RSMTestable stateRSM = new(); // Instance of the class holding the active states.

        public CallQueueState callQueueState = new(); // The state of the call queue.

        /// <summary>
        /// Dictionary<correlationId, Action>
        /// </summary>
        public Dictionary<string, Action> ActionCorrelation = new();

        /// <summary>
        /// Dictionary<callId, IncomingQueuedCall>
        /// </summary>
        public Dictionary<string, IncomingQueuedCall> callQueue = new();

        public WebSocketClient webSocketClient;
        public string url; // The URL of the INTCAPI server.
        public string agencyId; // The agencyId of the agency that is being subscribed to.
        public string secret;  // The secret of the agency that is being subscribed to.
        public string username; // The username of the webSocketClient connection.
        public string password; // The password of the webSocketClient connection.
        private static bool bDebug = false;

        public void OnMessage(Events.Message e)
        {
            MessageReceivedEvent?.Invoke(this, e);
        }

        public void OnLocation(Events.Location e)
        {
            LocationReceivedEvent?.Invoke(this, e);
        }

        public void Dispose()
        {
            webSocketClient.Dispose();
            GC.SuppressFinalize(this);
        }

        public event EventHandler<Events.Message>? MessageReceivedEvent;
        public event EventHandler<Events.Location>? LocationReceivedEvent;

        // Constructor to initialize the RSM with initial states and values.
        public ConnectionRSM(Configuration config)
        {
            webSocketClient = new WebSocketClient();

            callQueueState = CallQueueState.Empty;

            if (string.IsNullOrEmpty(config.Uri)) throw new ArgumentNullException(nameof(config.Uri));
            if (string.IsNullOrEmpty(config.Username)) throw new ArgumentNullException(nameof(config.Username));
            if (string.IsNullOrEmpty(config.Password)) throw new ArgumentNullException(nameof(config.Password));
            if (string.IsNullOrEmpty(config.AgencyId)) throw new ArgumentNullException(nameof(config.AgencyId));
            if (string.IsNullOrEmpty(config.Secret)) throw new ArgumentNullException(nameof(config.Secret));

            this.url = config.Uri;
            this.username = config.Username;
            this.password = config.Password;
            this.agencyId = config.AgencyId;
            this.secret = config.Secret;
        }

        //Handle events and transition between states accordingly.
        public static async Task HandleEvent(Action action, ConnectionRSM connectionRSM, RSMTestable.Testable stateToTest, RSMStates rsmStateToWaitfor, int timeout = 1000)
        {

            bool bTimedOut = false;
            //Add a timer to timeout if we don't get the expected state
            var timer = new System.Timers.Timer(timeout);
            timer.Elapsed += (sender, e) =>
            {
                bTimedOut = true;
            };
            timer.Start();

            RSMStates? potentialState = connectionRSM.stateRSM.ReturnTestable(stateToTest) as RSMStates?;
            RSMStates actualState = potentialState ?? default;

            // Test the state to see if we are already in the state we want to be in.
            if (actualState == rsmStateToWaitfor)
            {
                // if (bDebug) AnsiConsole.MarkupLine($"[bold grey]RSM: !!!Already in {rsmStateToWaitfor}[/]");
                return;
            }

            // Perform our action
            await HandleEvent(action, connectionRSM, null, null);

            // AnsiConsole.MarkupLine($"[bold red]RSM: Waiting for {rsmStateToWaitfor}....[/]");

            // Wait for event to change, if we reach timeout before the expected state we simply return
            // AnsiConsole.MarkupLine($"[bold grey]RSM: While({actualState} != {rsmStateToWaitfor})[/]");
            while (actualState != rsmStateToWaitfor)
            {
                await Task.Delay(10);
                if (bTimedOut)
                {
                    // if (bDebug) AnsiConsole.MarkupLine($"[bold grey]\nRSM: Timed Out waiting for {rsmStateToWaitfor}[/]");
                    break;
                }
            }
        }

        // Handle events and transition between states accordingly, with optional message and action. One or the other is required based on action or reaction(event) being handled.
        public static async Task HandleEvent(Action? action, ConnectionRSM connectionRSM, object? message, ConsoleInput? consoleInput)
        {
            string correlationId = Guid.NewGuid().ToString();

            if (message != null && action == null)
            {
                GenericEventMessage? eventMessage = (GenericEventMessage)message;

                if (eventMessage.CorrelationId != null)
                {
                    correlationId = eventMessage.CorrelationId;
                    //This is a response, Look up Action based on correlationID.
                    if (connectionRSM.ActionCorrelation.ContainsKey(correlationId))
                    {
                        action = connectionRSM.ActionCorrelation[correlationId]; //Set the action based on the correlationID.
                    }
                    else
                    {
                        if (bDebug) AnsiConsole.MarkupLine($"[bold grey]{DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss.fff tt")} - RSM: Action not found for correlationId: {0}[/]", correlationId);
                    }
                }
                else
                {
                    if (bDebug) AnsiConsole.MarkupLine($"[bold grey]{DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss.fff tt")} - RSM: CorrelationId is null[/]");
                }
            }
            else if (action != null) //Action is not null, we are executing a new Action, we must create and record our correlationId.
            {
                connectionRSM.ActionCorrelation.Add(correlationId, (Action)action); //We are executing a new Action, we must record our correlationId.
            }

            switch (action)
            {
                // 1st Step, connect the WebSocket client to the API server.
                case Action.Connect: // There is no correlationID for this request.
                    if (connectionRSM.stateRSM.connectionState == RSMStates.ConnectionDisconnected)
                    {
                        //Connect the WebSocket client to the API server.
                        await connectionRSM.webSocketClient.ConnectAsync(connectionRSM.url, connectionRSM.username, connectionRSM.password, CancellationToken.None);

                        //Test the above webSocketClient to make sure it is connected.
                        if (connectionRSM.webSocketClient._webSocket != null && connectionRSM.webSocketClient._webSocket.State != WebSocketState.Open)
                        {
                            //Add a console message of the error
                            if (bDebug) AnsiConsole.MarkupLine($"[bold grey]{DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss.fff tt")} - RSM: ConnectionLost[/]");
                            //Set the state to ConnectionLost
                            connectionRSM.stateRSM.connectionState = RSMStates.ConnectionLost;
                            //Dispose of the webSocketClient
                            connectionRSM.webSocketClient._webSocket.Dispose();
                            break;
                        }

                        // Listen for incoming events
#pragma warning disable CS4014 // Because this call is not awaited, execution of the current method continues before the call is completed
                        Task.Run(() => WebSocketClient.ListenForIncomingEventsAsync(connectionRSM.webSocketClient, connectionRSM, CancellationToken.None));
#pragma warning restore CS4014 // Because this call is not awaited, execution of the current method continues before the call is completed
                        connectionRSM.stateRSM.connectionState = RSMStates.ConnectionConnected;
                        if (correlationId != null) connectionRSM.ActionCorrelation.Remove(correlationId); // Time to remove the state from the correlationId, it is over now.
                        else
                        {
                            if (bDebug) AnsiConsole.MarkupLine($"[bold grey]{DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss.fff tt")} - RSM: Connect Action has no correlationId[/]");
                        }

                        if (bDebug) AnsiConsole.MarkupLine($"[bold grey]{DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss.fff tt")} - RSM: Connected to the network.[/]");
                    }
                    else if (connectionRSM.stateRSM.connectionState == RSMStates.ConnectionConnected)
                    {
                        if (bDebug) AnsiConsole.MarkupLine($"[bold grey]{DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss.fff tt")} - Already connected to the network.[/]");
                    }
                    else if (connectionRSM.stateRSM.connectionState == RSMStates.ConnectionLost)
                    {
                        // TODO: Retry the connection...
                        if (bDebug) AnsiConsole.MarkupLine($"[bold grey]{DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss.fff tt")} - Cannot connect while connection is lost. Please try again later.[/]");
                    }
                    break;

                case Action.Disconnect:
                    if (connectionRSM.stateRSM.connectionState == RSMStates.ConnectionConnected)
                    {
                        // unregister calls
                        // unregister agency

                        // Disconnect
                        await connectionRSM.webSocketClient.DisconnectAsync(CancellationToken.None);
                        connectionRSM.stateRSM.connectionState = RSMStates.ConnectionDisconnected;
                        if (bDebug) AnsiConsole.MarkupLine($"[bold grey]{DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss.fff tt")} - Disconnected from the network.[/]");
                    }
                    else if (connectionRSM.stateRSM.connectionState == RSMStates.ConnectionDisconnected)
                    {
                        if (bDebug) AnsiConsole.MarkupLine($"[bold grey]{DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss.fff tt")} - Already disconnected from the network.[/]");
                    }
                    else if (connectionRSM.stateRSM.connectionState == RSMStates.ConnectionLost)
                    {
                        if (bDebug) AnsiConsole.MarkupLine($"[bold grey]{DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss.fff tt")} - Cannot disconnect while connection is lost. Please try again later.[/]");
                    }
                    break;

                case Action.SubscribeAgency:

                    if (connectionRSM.stateRSM.agencySubscriptionState == RSMStates.AgencyUnsubscribed)
                    {
                        connectionRSM.stateRSM.agencySubscriptionState = RSMStates.AgencySubscribing; //Imediately enter into the current state.
                        if (bDebug) AnsiConsole.MarkupLine($"[bold grey]{DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss.fff tt")} - RSM: Subscribing to Agency Channel.[/]");
                        await connectionRSM.webSocketClient.SubscribeToAgencyActionAsync(connectionRSM.agencyId, connectionRSM.secret, connectionRSM, correlationId, CancellationToken.None); // Call our SubscribeToAgencyActionAsync method.

                    }
                    else if (connectionRSM.stateRSM.agencySubscriptionState == RSMStates.AgencySubscribing) //We recieved a message from the server that we are subscribed.
                    {
                        connectionRSM.stateRSM.agencySubscriptionState = RSMStates.AgencySubscribed;
                        if (bDebug) AnsiConsole.MarkupLine($"[bold grey]{DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss.fff tt")} - RSM -> RSMStates.AgencySubscribing -> CorrelationId: {correlationId}[/]");
                        connectionRSM.ActionCorrelation.Remove(correlationId);

                        if (bDebug) AnsiConsole.MarkupLine($"[bold grey]{DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss.fff tt")} - RSM: Subscribed to Agency Channel.[/]");
                    }
                    else if (connectionRSM.stateRSM.agencySubscriptionState == RSMStates.AgencySubscribed)
                    {
                        if (bDebug) AnsiConsole.MarkupLine($"[bold grey]{DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss.fff tt")} - RSM: Already subscribed.[/]");
                    }
                    break;

                case Action.UnsubscribeAgency:
                    if (bDebug) AnsiConsole.MarkupLine($"[bold grey]{DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss.fff tt")} - Performing Action UnsubscribeAgency.[/]");
                    if (connectionRSM.stateRSM.agencySubscriptionState == RSMStates.AgencySubscribed)
                    {
                        connectionRSM.stateRSM.agencySubscriptionState = RSMStates.AgencyUnsubscribed;
                        if (bDebug) AnsiConsole.MarkupLine($"[bold grey]{DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss.fff tt")} - Unsubscribed successfully.[/]");
                    }
                    else if (connectionRSM.stateRSM.agencySubscriptionState == RSMStates.AgencyUnsubscribed)
                    {
                        if (bDebug) AnsiConsole.MarkupLine($"[bold grey]{DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss.fff tt")} - Already unsubscribed.[/]");
                    }
                    break;

                case Action.RegisterAgency:
                    if (connectionRSM.stateRSM.registrationState == RSMStates.AgencyNotRegistered)
                    {
                        connectionRSM.stateRSM.registrationState = RSMStates.AgencyRegistering;
                        if (bDebug) AnsiConsole.MarkupLine($"[bold grey]{DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss.fff tt")} - RSM: Registering[/]");
                        await connectionRSM.webSocketClient.RegisterAgencyActionAsync(connectionRSM.agencyId, connectionRSM.secret, connectionRSM, correlationId, CancellationToken.None);
                    }
                    else if (connectionRSM.stateRSM.registrationState == RSMStates.AgencyRegistering)
                    {
                        if (message != null)
                        {

                            if (((ResponseMessage)message).ResponseStatusCode == 200)
                            {
                                connectionRSM.registerToken = ((ResponseMessage)message).RegisterToken;
                                connectionRSM.stateRSM.registrationState = RSMStates.AgencyRegistered;
                                if (bDebug) AnsiConsole.MarkupLine($"[bold grey]RSM: Succesfully Registered to Agency: {((ResponseMessage)message).RegisterToken}[/]");
                            } // TODO: if not 200 OK, then what...
                            connectionRSM.ActionCorrelation.Remove(correlationId);
                        }
                    }
                    else if (connectionRSM.stateRSM.registrationState == RSMStates.AgencyRegistered)
                    {
                        if (bDebug) AnsiConsole.MarkupLine($"[bold grey]{DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss.fff tt")} - Already registered.[/]");
                    }
                    break;

                case Action.SubscribeCalls:
                    if (connectionRSM.stateRSM.callsSubscriptionState == RSMStates.CallsUnsubscribed)
                    {
                        connectionRSM.stateRSM.callsSubscriptionState = RSMStates.CallsSubscribing;
                        if (bDebug) AnsiConsole.MarkupLine($"[bold grey]{DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss.fff tt")} - RSM: Subscribing to Call Events[/]");
                        await connectionRSM.webSocketClient.SubscribeToCallsActionAsync(connectionRSM, correlationId, CancellationToken.None);

                    }
                    else if (connectionRSM.stateRSM.callsSubscriptionState == RSMStates.CallsSubscribing)
                    {
                        if (message != null)
                        {
                            if (((ResponseMessage)message).ResponseStatusCode == 200)
                            {
                                connectionRSM.stateRSM.callsSubscriptionState = RSMStates.CallsSubscribed;
                                if (bDebug) AnsiConsole.MarkupLine($"[bold grey]RSM: Succesfully Subscribed to Call Events[/]");
                            }
                            connectionRSM.ActionCorrelation.Remove(correlationId);
                        }

                    }
                    else if (connectionRSM.stateRSM.callsSubscriptionState == RSMStates.CallsSubscribed)
                    {
                        if (bDebug) AnsiConsole.MarkupLine($"[bold grey]{DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss.fff tt")} - Already registered.[/]");
                    }
                    break;

                case Action.CallsSubscribed:
                    if (connectionRSM.stateRSM.callsSubscriptionState == RSMStates.CallsSubscribing)
                    {
                        connectionRSM.stateRSM.callsSubscriptionState = RSMStates.CallsSubscribed;
                        if (bDebug) AnsiConsole.MarkupLine($"[bold grey]RSM: Call Events Channel was Succesfully Subscribed to.[/]");
                    }
                    else if (connectionRSM.stateRSM.callsSubscriptionState == RSMStates.CallsSubscribed)
                    {
                        if (bDebug) AnsiConsole.MarkupLine($"[bold grey]{DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss.fff tt")} - RSM Out of Sequence, Call Events Channel is already Subscribed.[/]"); //TODO Update anything?
                    }
                    else if (connectionRSM.stateRSM.callsSubscriptionState == RSMStates.CallsUnsubscribed)
                    {
                        if (bDebug) AnsiConsole.MarkupLine($"[bold grey]{DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss.fff tt")} - RSM Out of Sequence, Call Events Channel is UnSubscribed not Subscribing.[/]");
                    }
                    break;

                case Action.AgencySubscribed:
                    if (connectionRSM.stateRSM.agencySubscriptionState == RSMStates.AgencySubscribing)
                    {
                        connectionRSM.stateRSM.agencySubscriptionState = RSMStates.AgencySubscribed;
                        if (bDebug) AnsiConsole.MarkupLine($"[bold grey]RSM: Agency Channel was Succesfully Subscribed to.[/]");
                    }
                    else if (connectionRSM.stateRSM.agencySubscriptionState == RSMStates.AgencySubscribed)
                    {
                        if (bDebug) AnsiConsole.MarkupLine($"[bold grey]{DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss.fff tt")} - RSM Out of Sequence, Agency is already Subscribed.[/]"); //TODO Update anything?
                    }
                    else if (connectionRSM.stateRSM.agencySubscriptionState == RSMStates.AgencyUnsubscribed)
                    {
                        if (bDebug) AnsiConsole.MarkupLine($"[bold grey]{DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss.fff tt")} - RSM Out of Sequence, Agency is UnSubscribed not Subscribing.[/]");
                    }
                    break;

                case Action.AgencyRegistered:
                    if (connectionRSM.stateRSM.registrationState == RSMStates.AgencyRegistering)
                    {
                        connectionRSM.stateRSM.registrationState = RSMStates.AgencyRegistered;
                        if (bDebug) AnsiConsole.MarkupLine($"[bold grey]Registered successfully with Token: {connectionRSM.registerToken}[/]");
                    }
                    else if (connectionRSM.stateRSM.registrationState == RSMStates.AgencyNotRegistered)
                    {
                        if (bDebug) AnsiConsole.MarkupLine($"[bold grey]{DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss.fff tt")} - 123 Out of Sequence, Registered but not Registering.[/]");
                    }
                    else if (connectionRSM.stateRSM.registrationState == RSMStates.AgencyRegistered)
                    {
                        if (bDebug) AnsiConsole.MarkupLine($"[bold grey]{DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss.fff tt")} - Already registered.[/]");
                    }
                    break;

                case Action.UnregisterAgency:
                    if (connectionRSM.stateRSM.registrationState == RSMStates.AgencyRegistered)
                    {
                        connectionRSM.stateRSM.registrationState = RSMStates.AgencyNotRegistered;
                        if (bDebug) AnsiConsole.MarkupLine($"[bold grey]{DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss.fff tt")} - Unregistered successfully.[/]");
                    }
                    else if (connectionRSM.stateRSM.registrationState == RSMStates.AgencyNotRegistered)
                    {
                        if (bDebug) AnsiConsole.MarkupLine($"[bold grey]{DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss.fff tt")} - Already unregistered.[/]");
                    }
                    break;
                case Action.CallQueueRequest:
                    // SendRequestCallQueueActionAsync
                    await connectionRSM.webSocketClient.SendRequestCallQueueActionAsync(connectionRSM, CancellationToken.None);
                    break;
                case Action.AcceptCall:
                    IncomingQueuedCall? queuedCall = null;
                    if (connectionRSM.stateRSM.callQueueState == RSMStates.CallPresented) //We are processing a call presented event with an action to answer the call
                    {
                        //Get the first Call in a presented state.
                        queuedCall = connectionRSM.callQueue.Where(x => x.Value.CallsState == IncomingQueuedCall.CallState.Presented).FirstOrDefault().Value;
                        string callID = queuedCall.CallID; //Get callID
                        queuedCall.CallsState = IncomingQueuedCall.CallState.Answering; //Set this call to answering
                        queuedCall.RecentCorrelationID = correlationId; //Store the correlationId for this AcceptCall action.

                        connectionRSM.stateRSM.callQueueState = RSMStates.CallAnswering; //Set our current state of answering waiting for response.
                                                                                         //Perform the action to answer this call
                        await connectionRSM.webSocketClient.AcceptCallActionAsync(connectionRSM, correlationId, callID, CancellationToken.None);

                        if (bDebug) AnsiConsole.MarkupLine($"[bold grey]RSM: Answering Call: {callID}[/]");
                    }
                    else if (connectionRSM.stateRSM.callQueueState == RSMStates.CallAnswering) //We are processing a response to an answercall action
                    {
                        //Find the answered call in the callQueue using the correlationId
                        queuedCall = connectionRSM.callQueue.Where(x => x.Value.RecentCorrelationID == correlationId).FirstOrDefault().Value;

                        //If the call is successfully answered then clear the correlationId and set the call state to answered.
                        if (message != null)
                        {
                            if (((ResponseMessage)message).ResponseStatusCode == 200)
                            {
                                connectionRSM.stateRSM.callQueueState = RSMStates.CallAnswered;
                                queuedCall.CallsState = IncomingQueuedCall.CallState.Answered;

                                if (bDebug) AnsiConsole.MarkupLine($"[bold grey]RSM: Succesfully Answered Call: {queuedCall.CallID}[/]");
                            }
                            connectionRSM.ActionCorrelation.Remove(correlationId);
                        }
                    }
                    else if (connectionRSM.stateRSM.callQueueState == RSMStates.CallAnswered)
                    {
                        if (bDebug) AnsiConsole.MarkupLine($"[bold grey]{DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss.fff tt")} - RSM Out of Sequence, Call is already Answered.[/]");
                    }
                    else if (connectionRSM.stateRSM.callQueueState == RSMStates.CallEnded)
                    {
                        if (bDebug) AnsiConsole.MarkupLine($"[bold grey]{DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss.fff tt")} - RSM Out of Sequence, Call is Ended not Answering.[/]");
                    }
                    else
                    {
                        if (bDebug) AnsiConsole.MarkupLine($"[bold grey]{DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss.fff tt")} - RSM Out of Sequence, Call is not Presented.[/]");
                    }
                    break;
                case Action.CallPresented:
                    if (connectionRSM.stateRSM.callQueueState == RSMStates.ProcessQueue || connectionRSM.stateRSM.callQueueState == RSMStates.CallPresented) // We have an empty queue
                    {
                        if (message == null)
                        {
                            if (bDebug) AnsiConsole.MarkupLine($"[bold grey]{DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss.fff tt")} - RSM: CallPresented Inconsistent State[/]");
                            break;
                        }

                        //Extract the callID from the message
                        var callID = ((CallEventMessage)message).Call.CallId;
                        //Create a new IncomingQueuedCall object
                        IncomingQueuedCall newQueuedCall = new()
                        {
                            CallEvent = ((CallEventMessage)message).Call,
                            CallsState = IncomingQueuedCall.CallState.Presented,
                            CallID = callID
                        };
                        //Add the new IncomingQueuedCall object to the callQueue Dictionary
                        connectionRSM.callQueue.Add(callID, newQueuedCall);
                        //connectionRSM.callQueue.Enqueue(newQueuedCall);

                        connectionRSM.stateRSM.callQueueState = RSMStates.CallPresented; // We got a call to process.

                        // AnsiConsole.MarkupLine($"[bold grey]\nRSM: Call is waiting to be answered: {callID}\r[/]");
                    }
                    else
                    {
                        if (bDebug) AnsiConsole.MarkupLine($"[bold grey]{DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss.fff tt")} - RSM: CallPresented Inconsistent State[/]");
                    }
                    break;
                case Action.ProcessQueue:
                    if (connectionRSM.stateRSM.callsSubscriptionState == RSMStates.CallsSubscribed) // We are subscribed and not already processing a call
                    {
                        connectionRSM.stateRSM.callQueueState = RSMStates.ProcessQueue; // We are processing the queue
                                                                                        //Process the queue
                                                                                        // if (bDebug) AnsiConsole.MarkupLine($"[bold grey]{DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss.fff tt")} - RSM: ProcessQueue[/]");
                    }
                    break;
                case Action.SendMessage:
                    // get the userInput.callId and userInput.message
                    if (consoleInput == null)
                    {
                        if (bDebug) AnsiConsole.MarkupLine($"[bold grey]{DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss.fff tt")} - RSM: SendMessage Action requires a ConsoleInput object.[/]");
                        break;
                    }

                    // get the call from the callQueue using the userInput.callId
                    queuedCall = connectionRSM.callQueue.Where(x => x.Value.CallID == consoleInput.callId).FirstOrDefault().Value;

                    // if the queuedCall is null then we don't have a call with that callId
                    if (queuedCall == null)
                    {
                        if (bDebug) AnsiConsole.MarkupLine($"[bold grey]{DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss.fff tt")} - RSM: The call does not exist in the callQueue.[/]");
                        break;
                    }

                    // if the call is not answered then we can't send a message
                    if (queuedCall.CallsState != IncomingQueuedCall.CallState.Answered)
                    {
                        if (bDebug) AnsiConsole.MarkupLine($"[bold grey]{DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss.fff tt")} - RSM: The call is not answered.[/]");
                        break;
                    }

                    // if the call is answered then we can send a message
                    if (queuedCall.CallsState == IncomingQueuedCall.CallState.Answered)
                    {
                        if (consoleInput.callId == null || consoleInput.message == null) // if the callId or message is null then we can't send a message
                        {
                            if (bDebug) AnsiConsole.MarkupLine($"[bold grey]{DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss.fff tt")} - RSM: SendMessage Action requires a callId and message.[/]");
                            break;
                        }

                        // send the message to the call
                        await connectionRSM.webSocketClient.SendMessageActionAsync(connectionRSM, consoleInput.callId, consoleInput.message, CancellationToken.None);
                    }


                    break;
                case Action.ReceiveMessage:
                    if (connectionRSM.stateRSM.agencySubscriptionState == RSMStates.AgencySubscribed)
                    {
                        if (message == null)
                        {
                            if (bDebug) AnsiConsole.MarkupLine($"[bold grey]{DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss.fff tt")} - RSM: ReceiveMessage Inconsistent State[/]");
                            break;
                        }

                        //Extract the callID from the message
                        var messageEvent = (MessageEvent)message;

                        // get the call
                        queuedCall = connectionRSM.callQueue.Where(x => x.Value.CallID == messageEvent.CallId).FirstOrDefault().Value;

                        if (queuedCall.CallsState == IncomingQueuedCall.CallState.Answered)
                        {
                            Events.Message e = new()
                            {
                                body = messageEvent.Message.Body,
                                to = messageEvent.Message.To,
                                from = messageEvent.Message.From,
                                dateTime = messageEvent.Message.DateTime,
                                callId = messageEvent.CallId
                            };

                            connectionRSM.OnMessage(e);
                        }

                    }
                    else
                    {
                        if (bDebug) AnsiConsole.MarkupLine($"[bold grey]{DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss.fff tt")} - RSM: ReceiveMessage Inconsistent State[/]");
                    }
                    break;
                case Action.EndCall:

                    IncomingQueuedCall? queuedCallEnd = null;
                    if (consoleInput == null)
                    {
                        if (bDebug) AnsiConsole.MarkupLine($"[bold grey]{DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss.fff tt")} - RSM: SendMessage Action requires a ConsoleInput object.[/]");
                        break;
                    }

                    // get the call from the callQueue using the consoleInput.callId
                    queuedCallEnd = connectionRSM.callQueue.Where(x => x.Value.CallID == consoleInput.callId).FirstOrDefault().Value;

                    // if the queuedCall is null then we don't have a call with that callId
                    if (queuedCallEnd == null)
                    {
                        if (bDebug) AnsiConsole.MarkupLine($"[bold grey]{DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss.fff tt")} - RSM: The call does not exist in the callQueue.[/]");
                        break;
                    }

                    // if the call is not answered then we can't end the call
                    if (queuedCallEnd.CallsState != IncomingQueuedCall.CallState.Answered)
                    {
                        if (bDebug) AnsiConsole.MarkupLine($"[bold grey]{DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss.fff tt")} - RSM: The call is not answered.[/]");
                        break;
                    }

                    // if the call is answered then we can end the call
                    if (queuedCallEnd.CallsState == IncomingQueuedCall.CallState.Answered)
                    {
                        if (consoleInput.callId == null) // if the callId is null then we can't end the call
                        {
                            if (bDebug) AnsiConsole.MarkupLine($"[bold grey]{DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss.fff tt")} - RSM: EndCall Action requires a callId.[/]");
                            break;
                        }

                        // end the call
                        await connectionRSM.webSocketClient.EndCallActionAsync(connectionRSM, consoleInput.callId, "Your session was ended", CancellationToken.None);

                        // waiting to end...
                        // await HandleEvent(Action.CallEnded, connectionRSM, RSMTestable.Testable.CallQueue, RSMStates.QueueIdle, 1000);
                    }


                    break;
                case Action.CallAccepted:
                    if (message == null)
                    {
                        break;
                    }

                    CallEventMessage acceptedCall = (CallEventMessage)message;
                    if (acceptedCall == null || acceptedCall.Call == null || acceptedCall.Call.CallId == null)
                    {
                        break;
                    }

                    IncomingQueuedCall acceptedCallInQueue = connectionRSM.callQueue.Where(x => x.Value.CallID == acceptedCall.Call.CallId).FirstOrDefault().Value;
                    acceptedCallInQueue.CallsState = IncomingQueuedCall.CallState.Answered;
                    acceptedCallInQueue.CallEvent = acceptedCall.Call;

                    // set rsm state
                    connectionRSM.stateRSM.callQueueState = RSMStates.ProcessQueue;

                    break;
                case Action.CallMissed:
                    if (message == null)
                    {
                        break;
                    }

                    CallEventMessage missedCall = (CallEventMessage)message;
                    if (missedCall == null || missedCall.Call == null || missedCall.Call.CallId == null)
                    {
                        break;
                    }

                    IncomingQueuedCall missedCallInQueue = connectionRSM.callQueue.Where(x => x.Value.CallID == missedCall.Call.CallId).FirstOrDefault().Value;
                    missedCallInQueue.CallsState = IncomingQueuedCall.CallState.Answered;
                    missedCallInQueue.CallEvent = missedCall.Call;

                    // set rsm state
                    connectionRSM.stateRSM.callQueueState = RSMStates.ProcessQueue;
                    break;
                case Action.CallEnded:

                    if (message == null)
                    {
                        AnsiConsole.MarkupLine("[bold red]Message is null![/]");
                        break;
                    }

                    // get the message
                    CallEventMessage endedCall = (CallEventMessage)message;

                    if (endedCall == null || endedCall.Call == null || endedCall.Call.CallId == null)
                    {
                        AnsiConsole.MarkupLine("[bold red]Ended call or Call ID is null![/]");
                        break;
                    }

                    IncomingQueuedCall endedCallInQueue = connectionRSM.callQueue.Where(x => x.Value.CallID == endedCall.Call.CallId).FirstOrDefault().Value;

                    if (endedCallInQueue == null)
                    {
                        AnsiConsole.MarkupLine("[bold red]Action.CallEnded: Call was not found in queue![/]");
                        break;
                    }

                    // remove ended call
                    // connectionRSM.callQueue.Remove(endedCall.Call.CallId);

                    // AnsiConsole.MarkupLine($"[bold gray]Removed {endedCall.Call.CallId} from queue.[/]");
                    endedCallInQueue.CallEvent = endedCall.Call;
                    break;
                case Action.ReceiveLocation:
                    if (connectionRSM.stateRSM.agencySubscriptionState == RSMStates.AgencySubscribed)
                    {
                        if (message == null)
                        {
                            if (bDebug) AnsiConsole.MarkupLine($"[bold grey]{DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss.fff tt")} - RSM: ReceiveLocation Inconsistent State[/]");
                            break;
                        }

                        //Extract the callID from the message
                        var locationEvent = (LocationEvent)message;

                        // get the call
                        queuedCall = connectionRSM.callQueue.Where(x => x.Value.CallID == locationEvent.CallId).FirstOrDefault().Value;

                        if (queuedCall.CallsState == IncomingQueuedCall.CallState.Answered)
                        {
                            Events.Location e = new()
                            {
                                latitude = locationEvent.Location.LocationInfo.Latitude,
                                longitude = locationEvent.Location.LocationInfo.Longitude,
                                elevation = locationEvent.Location.LocationInfo.Elevation,
                                dateTime = locationEvent.Location.DateTime,
                                callId = locationEvent.CallId
                            };

                            connectionRSM.OnLocation(e);
                        }

                    }
                    else
                    {
                        if (bDebug) AnsiConsole.MarkupLine($"[bold grey]{DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss.fff tt")} - RSM: ReceiveMessage Inconsistent State[/]");
                    }
                    break;
                default:
                    if (bDebug) AnsiConsole.MarkupLine($"[bold grey]{DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss.fff tt")} - RSM: Unrecognized Event.[/]");
                    break;
            }
        }

        public static async Task HandleCallEventAsync(CallEventMessage callEventMessage, ConnectionRSM connectionRSM, CancellationToken cancellationToken)
        {
            if (bDebug) AnsiConsole.MarkupLine($"[bold grey]RSM: Handling call state: {callEventMessage.Call.CallState} for CallID: {callEventMessage.Call.CallId}[/]");
            if (callEventMessage.Call.CallType == "inbound" && callEventMessage.Call.CallState == "presented") // Incoming call, need to decide what to do.
                await HandleEvent(Action.CallPresented, connectionRSM, callEventMessage, null);
            else if (callEventMessage.Call.CallState == "accepted")
                await HandleEvent(Action.CallAccepted, connectionRSM, callEventMessage, null);
            else if (callEventMessage.Call.CallState == "missed")
                await HandleEvent(Action.CallMissed, connectionRSM, callEventMessage, null);
            else if (callEventMessage.Call.CallState == "ended")
                await HandleEvent(Action.CallEnded, connectionRSM, callEventMessage, null);
        }

        public static async Task HandleMessageEventAsync(MessageEvent messageEvent, ConnectionRSM connectionRSM, CancellationToken cancellationToken)
        {
            if (bDebug) AnsiConsole.MarkupLine($"[bold grey]RSM: Handling message event for CallID: {messageEvent.CallId}[/]");
            await HandleEvent(Action.ReceiveMessage, connectionRSM, messageEvent, null);
        }

        internal static async Task HandleLocationEventAsync(LocationEvent locationEvent, ConnectionRSM connectionRSM, CancellationToken cancellationToken)
        {
            if (bDebug) AnsiConsole.MarkupLine($"[bold grey]RSM: Handling location event for CallID: {locationEvent.CallId}[/]");
            await HandleEvent(Action.ReceiveLocation, connectionRSM, locationEvent, null);
        }
    }

    public class Events
    {
        public class Message : EventArgs
        {
            public string? body;
            public string? to;
            public string? from;
            public string? dateTime;
            public string? callId;
        }
        public class Location : EventArgs
        {
            public string? latitude;
            public string? longitude;
            public string? elevation;
            public string? dateTime;
            public string? callId;
        }
    }

    public class ConsoleInput
    {
        public string? callId;
        public string? message;
    }
}